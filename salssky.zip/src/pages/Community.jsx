import React from "react";
import Level2 from "./community/Level2";
import CommunityChat from "./community";

const Community = () => {
    // return <Level2 />;
    return <CommunityChat />;
};

export default Community;
